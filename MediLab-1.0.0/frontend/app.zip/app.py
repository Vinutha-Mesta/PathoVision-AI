import os
import uuid
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
from PIL import Image
import numpy as np
from tensorflow.keras.models import load_model

# Optional: for Grad-CAM plotting
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Config
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'images', 'uploads')
HEATMAP_FOLDER = os.path.join(BASE_DIR, 'static', 'images', 'heatmaps')
MODEL_FOLDER = os.path.join(BASE_DIR, 'models')

ALLOWED_EXT = {'png', 'jpg', 'jpeg', 'tiff', 'bmp'}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(HEATMAP_FOLDER, exist_ok=True)
os.makedirs(MODEL_FOLDER, exist_ok=True)

app = Flask(__name__)
app.secret_key = 'e425cf21833cf49d2da80704091c9238'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 12 * 1024 * 1024  # 12 MB limit

# ========== Model loading ==========
tier1_model = None
colon_stage_model = None
lung_stage_model = None

def load_models():
    global tier1_model, colon_stage_model, lung_stage_model
    try:
        tier1_model = load_model(os.path.join(MODEL_FOLDER, 'resnet50_core_model_finetuned.h5'))
        colon_stage_model = load_model(os.path.join(MODEL_FOLDER, 'densenet121_model_colon.h5'))
        lung_stage_model = load_model(os.path.join(MODEL_FOLDER, 'densenet121_model_lung.h5'))
        print("Models loaded successfully.")
    except Exception as e:
        print("Model load warning:", e)

# Call at startup
load_models()

# ========== Utility functions ==========
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT

def preprocess_image_for_model(img_path, target_size=(224,224)):
    img = Image.open(img_path).convert('RGB')
    img = img.resize(target_size)
    arr = np.array(img).astype('float32') / 255.0
    arr = np.expand_dims(arr, axis=0)
    return arr

# ========== Prediction placeholders ==========
def predict_tier1(img_path):
    val = hash(img_path) % 100
    organ = 'Colon' if val % 2 == 0 else 'Lung'
    status = 'Cancer' if val % 3 == 0 else 'Normal'
    confidence = 0.85
    return organ, status, confidence

def predict_stage(img_path, organ):
    val = (hash(img_path) % 4) + 1
    stage = f"Stage {val}"
    confidence = 0.78
    return stage, confidence

# ========== Grad-CAM placeholder ==========
def generate_gradcam_placeholder(img_path, save_to):
    try:
        base = Image.open(img_path).convert('RGB')
        arr = np.array(base).astype(np.float32)/255.0
        h, w = arr.shape[:2]
        yy, xx = np.mgrid[0:h, 0:w]
        cy, cx = h//2, w//2
        r = np.sqrt((xx-cx)*2 + (yy-cy)*2)
        r = (r.max() - r) / (r.max())
        heat = np.clip(r, 0, 1)
        cmap = plt.get_cmap('jet')
        heat_rgba = cmap(heat)[:,:,:3]
        overlay = (0.6 * heat_rgba + 0.4 * arr)
        overlay = np.clip(overlay, 0, 1)
        plt.figure(figsize=(6,6), dpi=100)
        plt.axis('off')
        plt.imshow(overlay)
        plt.tight_layout(pad=0)
        plt.savefig(save_to, bbox_inches='tight', pad_inches=0)
        plt.close()
        return True
    except Exception as e:
        print("Grad-CAM generation failed:", e)
        return False

# ========== Routes ==========
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/signup')
def signup():
    return render_template('signup.html')

@app.route('/analyze', methods=['GET','POST'])
def analyze():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            unique_name = f"{uuid.uuid4().hex}_{filename}"
            save_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_name)
            file.save(save_path)

            organ, status, conf1 = predict_tier1(save_path)

            stage = None
            conf_stage = None
            if status.lower() == 'cancer':
                stage, conf_stage = predict_stage(save_path, organ)

            heatmap_name = f"heatmap_{uuid.uuid4().hex}.png"
            heatmap_path = os.path.join(HEATMAP_FOLDER, heatmap_name)
            heat_ok = generate_gradcam_placeholder(save_path, heatmap_path)
            if not heat_ok:
                heatmap_name = None

            return render_template('results.html',
                                   organ=organ,
                                   status=status,
                                   confidence=round(conf1, 3),
                                   stage=stage,
                                   stage_confidence=round(conf_stage,3) if conf_stage else None,
                                   heatmap=('heatmaps/' + heatmap_name) if heatmap_name else None)
        else:
            flash('Unsupported file type. Allowed: png, jpg, jpeg, tiff, bmp', 'warning')
            return redirect(request.url)

    return render_template('analyze.html')

@app.route('/results')
def results():
    return render_template('results.html', organ=None, status=None, heatmap=None)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/methodology')
def methodology():
    return render_template('methodology.html')

@app.route('/contact', methods=['GET','POST'])
def contact():
    if request.method == 'POST':
        flash('Thanks — your message has been received.', 'success')
        return redirect(url_for('contact'))
    return render_template('contact.html')

@app.route('/disclaimer')
def disclaimer():
    return render_template('disclaimer.html')

if __name__ == '__main__':
    print("Starting Detectr+ Flask app...")
    print("Open in browser: http://127.0.0.1:5000/")
    app.run(host='0.0.0.0', port=5000, debug=True)